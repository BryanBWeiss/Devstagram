<?php return array (
  'like-post' => 'App\\Http\\Livewire\\LikePost',
);