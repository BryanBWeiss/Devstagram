

<?php $__env->startSection('titulo'); ?>
Crear Nueva Publicacion
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="md:flex md:items-center">
      <div class="md:w-1/2 px-10">
        <form action="<?php echo e(route('imagenes.store')); ?>" method="POST" enctype="multipart/form-data" id="dropzone" class=" bg-gray-300 dropzone border-dashed
        border-2 w-full h-96 rounded flex flex-col justify-center items-center">
        <?php echo csrf_field(); ?>
        </form>
        

      </div>

         <div class="md:w-1/2 px-10 bg-white p-6 rounded-lg shadow-xl mt-10 md:mt-0">
            <form action="<?php echo e(route('posts.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
    <div class="mb-5">
            <label for="titulo" class="mb-2   block uppercase text-gray-400 font-bold">
             Titulo
            </label>
              <input id="titulo" name="titulo" type="text" placeholder="Titulo de la publicacion"
                class="border p-3 w-full rounded-lg  <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('titulo')); ?>" />
              <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="bg-red-500 text-white my-2 rounded-lg text-sm p-2 text-center">
           <?php echo e($message); ?>

            </p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="mb-5">
        <label for="description" class="mb-2   block uppercase text-gray-400 font-bold">
         Descripcion
        </label>
          <textarea 
          id="description" name="description" 
          type="text" 
          placeholder="description de la publicacion"
          class="border p-3 w-full rounded-lg"><?php echo e(old('description')); ?></textarea>
          <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="bg-red-500 text-white my-2 rounded-lg text-sm p-2 text-center">
       <?php echo e($message); ?>

        </p>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

       <div class="mb-5 ">
             <input name="imagen"
                    type="hidden"
                    value="<?php echo e(old('imagen')); ?>"/>
                 <?php $__errorArgs = ['imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="bg-red-500 text-white my-2 rounded-lg text-sm p-2 text-center">
                <?php echo e($message); ?>

              </p>
     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
     </div>

  <input type="submit" value="Crear Publicacion"
  class="bg-sky-600 hover:bg-sky-
  transition-colors cursor-pointer uppercase  
  font-bold w-full p-3 text-white rounded-lg text-center" />


            </form>
         </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/posts/create.blade.php ENDPATH**/ ?>