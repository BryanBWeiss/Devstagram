   

   <?php $__env->startSection('titulo'); ?>
   Pagina Principal
   <?php $__env->stopSection(); ?>

   <?php $__env->startSection('inicio'); ?>
   Devstagram
   <?php $__env->stopSection(); ?>

   <?php $__env->startSection('contenido'); ?>
   contenido de la pagina
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/principal.blade.php ENDPATH**/ ?>